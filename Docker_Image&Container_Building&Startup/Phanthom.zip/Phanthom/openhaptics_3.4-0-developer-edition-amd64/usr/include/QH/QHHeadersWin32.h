
#include "Globals.h"
#include "DeviceSpace.h"
#include "QHWin32Class.h"
