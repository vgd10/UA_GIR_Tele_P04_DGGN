chmod 777 /dev/ttyACM0 && udevadm control --reload-rules && udevadm trigger && ./Touch_Setup
