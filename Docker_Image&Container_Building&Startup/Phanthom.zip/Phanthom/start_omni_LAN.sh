ufw allow 5353/udp && ./dependences/Phanthom/Touch_Setup
