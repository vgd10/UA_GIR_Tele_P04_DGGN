chmod 777 /dev/ttyACM0 && service udev restart && udevadm control --reload-rules && udevadm trigger	&& ./dependences/Phanthom/Touch_Setup
